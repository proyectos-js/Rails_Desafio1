class CuentaBancaria
  attr_accessor :name_user,
                :account_number,
                :vip
  def initialize(name_user, account_number, vip = 0)
      @name_user = name_user
      @account_number  = account_number
          if account_number.digits.count != 8 
              raise RangeError, "La cantidad de digitos es distinta a 8" 
          end
      @vip = vip    
  end
  def account
      if vip != 0 
          puts "1-#{account_number}"
      else
          puts "0-#{account_number}"
      end
  end
end
Account_vip = CuentaBancaria.new('Sandro', 12345678, 1)
puts Account_vip.account
